package com.example.springbootregistrationlogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootRegistrationLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootRegistrationLoginApplication.class, args);
	}

}
